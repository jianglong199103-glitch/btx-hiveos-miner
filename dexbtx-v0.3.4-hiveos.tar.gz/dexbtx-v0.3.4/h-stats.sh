#!/usr/bin/env bash

[[ -z ${SCRIPT_PATH:-} ]] && SCRIPT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
[[ -f "$SCRIPT_PATH/h-manifest.conf" ]] && source "$SCRIPT_PATH/h-manifest.conf"

log_file="${CUSTOM_LOG_BASENAME:-/var/log/miner/custom/dexbtx-v0.3.4}.log"
khs=0
acc=0
rej=0
uptime_sec=0

if [[ -f "$log_file" ]]; then
  acc=$(grep -ac "submitted" "$log_file" 2>/dev/null)
  rej=$(grep -ac "rejected\\|job stale\\|pool error" "$log_file" 2>/dev/null)

  sample=$(tail -n 120 "$log_file" 2>/dev/null | grep -a "nonce_start=" | tail -n 30)
  first=$(printf '%s\n' "$sample" | head -n 1)
  last=$(printf '%s\n' "$sample" | tail -n 1)

  if [[ "$first" =~ ^([0-9]{2}):([0-9]{2}):([0-9]{2}).*nonce_start=([0-9]+) ]]; then
    f_h=${BASH_REMATCH[1]}
    f_m=${BASH_REMATCH[2]}
    f_s=${BASH_REMATCH[3]}
    n1=${BASH_REMATCH[4]}
    if [[ "$last" =~ ^([0-9]{2}):([0-9]{2}):([0-9]{2}).*nonce_start=([0-9]+) ]]; then
      l_h=${BASH_REMATCH[1]}
      l_m=${BASH_REMATCH[2]}
      l_s=${BASH_REMATCH[3]}
      n2=${BASH_REMATCH[4]}
      t1=$((10#$f_h * 3600 + 10#$f_m * 60 + 10#$f_s))
      t2=$((10#$l_h * 3600 + 10#$l_m * 60 + 10#$l_s))
      [[ $t2 -lt $t1 ]] && t2=$((t2 + 86400))
      dt=$((t2 - t1))
      dn=$((n2 - n1))
      if [[ $dt -gt 0 && $dn -gt 0 ]]; then
        khs=$(awk -v dn="$dn" -v dt="$dt" 'BEGIN{printf "%.0f", dn / dt / 1000}')
      fi
    fi
  fi
fi

miner_pid=$(pgrep -f "dexbtx-miner" | head -1)
if [[ -n "$miner_pid" ]]; then
  uptime_sec=$(ps -o etimes= -p "$miner_pid" 2>/dev/null | tr -d ' ')
fi
[[ "$uptime_sec" =~ ^[0-9]+$ ]] || uptime_sec=0

if command -v jq >/dev/null 2>&1; then
  jq -nc \
    --argjson khs "$khs" \
    --argjson hs "[$khs]" \
    --arg hs_units "khs" \
    --argjson uptime "$uptime_sec" \
    --argjson ar "[$acc,$rej]" \
    --arg algo "matmul" \
    '{$khs,$hs,$hs_units,$uptime,$ar,$algo}'
else
  printf '{"khs":%s,"hs":[%s],"hs_units":"khs","uptime":%s,"ar":[%s,%s],"algo":"matmul"}\n' \
    "$khs" "$khs" "$uptime_sec" "$acc" "$rej"
fi
