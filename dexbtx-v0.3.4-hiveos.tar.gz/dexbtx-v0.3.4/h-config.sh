#!/usr/bin/env bash
set -euo pipefail

[[ -z ${SCRIPT_PATH:-} ]] && SCRIPT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
[[ -f "$SCRIPT_PATH/h-manifest.conf" ]] && source "$SCRIPT_PATH/h-manifest.conf"

conf_file="${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/dexbtx-v0.3.4/config.yaml}"
env_file="$SCRIPT_PATH/miner.env"
mkdir -p "$(dirname "$conf_file")"

raw_url="${CUSTOM_URL:-stratum+tcp://stratum.minebtx.com:3333}"
payout="${CUSTOM_TEMPLATE:-}"
pass="${CUSTOM_PASS:-x}"
worker="${WORKER_NAME:-${RIG_ID:-hiveos}}"

if [[ "$payout" == *.* ]]; then
  worker="${payout#*.}"
  payout="${payout%%.*}"
fi
worker="${worker//%WORKER_NAME%/${WORKER_NAME:-hiveos}}"
worker="${worker//%RIG_ID%/${RIG_ID:-hiveos}}"

tls=false
pool="${raw_url}"
case "$pool" in
  stratum+ssl://*|stratum+tls://*) tls=true; pool="${pool#*://}" ;;
  stratum+tcp://*) pool="${pool#stratum+tcp://}" ;;
  tcp://*) pool="${pool#tcp://}" ;;
  *) pool="${pool#*://}" ;;
esac

host="${pool%%:*}"
port="${pool##*:}"
if [[ "$host" == "$port" || -z "$port" ]]; then
  port=3333
fi

if [[ -z "$payout" ]]; then
  echo "ERROR: BTX payout address is empty. Fill Wallet template with btx1z..." >&2
  return 1 2>/dev/null || exit 1
fi

# Defaults are suitable for 3090/40-series NVIDIA cards. Extra config can
# override them with dexbtx-miner CLI flags.
{
  printf 'pool_host: "%s"\n' "$host"
  printf 'pool_port: %s\n' "$port"
  printf 'pool_tls: %s\n\n' "$tls"
  printf 'payout_address: "%s"\n' "$payout"
  printf 'worker_name: "%s"\n\n' "$worker"
  printf 'gbt_solve_path: "/root/.dexbtx-miner/bin/btx-gbt-solve"\n\n'
  printf 'solver_backend: "cuda"\n'
  printf 'solver_threads: 8\n'
  printf 'solver_batch_size: 128\n'
  printf 'solver_prefetch_depth: 8\n'
  printf 'solver_prepare_workers: 16\n'
  printf 'solver_pipeline_async: 1\n'
  printf 'gpu_inputs: 0\n\n'
  printf 'nonces_per_slice: 2000000\n'
  printf 'reconnect_initial_s: 1.0\n'
  printf 'reconnect_max_s: 60.0\n\n'
  printf 'log_level: "INFO"\n'
} > "$conf_file"

{
  printf 'DEXBTX_POOL_HOST=%q\n' "$host"
  printf 'DEXBTX_POOL_PORT=%q\n' "$port"
  printf 'DEXBTX_POOL_TLS=%q\n' "$tls"
  printf 'DEXBTX_PAYOUT=%q\n' "$payout"
  printf 'DEXBTX_WORKER=%q\n' "$worker"
  printf 'DEXBTX_PASS=%q\n' "$pass"
  printf 'DEXBTX_EXTRA_ARGS=( '
  # shellcheck disable=SC2206
  extra_args=( ${CUSTOM_USER_CONFIG:-} )
  for arg in "${extra_args[@]}"; do
    printf '%q ' "$arg"
  done
  printf ')\n'
} > "$env_file"

echo "Configuration written to $conf_file"
echo "Pool: $host:$port tls=$tls"
echo "Address: $payout"
echo "Worker: $worker"
return 0 2>/dev/null || exit 0
