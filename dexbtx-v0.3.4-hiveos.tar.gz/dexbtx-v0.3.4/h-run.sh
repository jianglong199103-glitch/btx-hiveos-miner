#!/usr/bin/env bash
set -euo pipefail

SCRIPT_PATH=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
[[ -f "$SCRIPT_PATH/h-manifest.conf" ]] && source "$SCRIPT_PATH/h-manifest.conf"
[[ -f "$SCRIPT_PATH/miner.env" ]] && source "$SCRIPT_PATH/miner.env"

LOG="${CUSTOM_LOG_BASENAME:-/var/log/miner/custom/dexbtx-v0.3.4}.log"
mkdir -p "$(dirname "$LOG")" /root/.dexbtx-miner/bin
exec > >(exec tee -a "$LOG") 2>&1

export PATH="/root/.local/bin:$HOME/.local/bin:$PATH"
export LD_LIBRARY_PATH="/usr/local/cuda/lib64:/hive/lib:${LD_LIBRARY_PATH:-}"

CONFIG="${CUSTOM_CONFIG_FILENAME:-/hive/miners/custom/dexbtx-v0.3.4/config.yaml}"
INSTALL_URL="${DEXBTX_INSTALL_URL:-https://minebtx.com/install.sh}"
POOL_ARG="${DEXBTX_POOL_HOST:-stratum.minebtx.com}:${DEXBTX_POOL_PORT:-3333}"

install_dexbtx() {
  echo "Installing dexbtx-miner from $INSTALL_URL"
  curl -fsSL "$INSTALL_URL" | bash -s -- \
    --address "${DEXBTX_PAYOUT:?missing payout address}" \
    --worker "${DEXBTX_WORKER:-hiveos}" \
    --pool "$POOL_ARG" \
    --yes \
    --skip-prompt
}

if ! command -v dexbtx-miner >/dev/null 2>&1 || [[ ! -x /root/.dexbtx-miner/bin/btx-gbt-solve ]]; then
  install_dexbtx
fi

echo "Starting dexbtx-miner"
echo "Config: $CONFIG"
echo "Extra args: disabled; solver tuning is written in config.yaml"

exec dexbtx-miner --config "$CONFIG"
